<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'reset' => 'Your password has been reset!',
    'sent' => 'We have emailed your password reset link!',
    'throttled' => 'Please wait before retrying.',
    'token' => 'This password reset token is invalid.',
    'user' => "We can't find a user with that email address.",

    //navbar
    'home' =>'Home',
    'about_Us' =>'About Us',
    'events' => 'Events',
    'projects' => 'Projects',
    'commercial' => 'Commercial',
    'residential' => 'Residential',
    'educational' => 'Coastal',
    'resort' => 'Sokhna',
    'media_Center' => 'Media Center ',
    'careers' => 'Careers',
    'contact' => 'Contact',
    'language' => 'Language',
    'sign_Up' => 'Sign Up',
    'entry' => 'Entry',
    'title' => 'Start your way now',
    'your' => 'Your journey with',
    'board_of_directors'=>'The word of the board of directors',
    'clientsay'=>'clientsay',
    'le'=>'L.E',
    'metr'=>'metar',
    'bedroom'=>'Bedroom',
    'bathroom'=>'Bathroom',
    'exclusives'=>'Our Exclusives',
    'properties'=>'Featured Properties',
    'commercial_pro' => ' Commercial Projects',
    'commercial_re' => ' Commercial Residential',
    'Quicklink'=>'Quick link',
    'address'=>'43 Makram Ebeid, Main - Nasr City - 7th floor - Flat 71',
    'Comments'=>'Leave a comment',
    'commercialprojects'=>'commercial projects',
    'educationalprojects'=>' Coastal projects',
    'Jobdetails'=>'Job details',
    'Workresponsibilities'=>'Work responsibilities',
    'Abouttheposition'=>'About the position',
    'Workrequirements'=>'Work requirements',
    'Feeton'=>'Feet on',
    'subject'=>'subject',
    'name'=>'name',
    'email'=>'email',
    'phone'=>'phone',
    'messege'=>'messege',
    'ProjectDetails'=>'Project Details',
    'Location'=>'Location',
    'EnterYourName'=>'Enter Your Name',
    'Yournamehere'=>'Your name here....',
    'EnterYourMAil'=>'Enter Your MAil',
    'Youremailhere'=>'Your email here....',
    'EnterYourMessege'=>'Enter Your Messege',
    'Enteryourmessegehere'=>'Enter your messege here....',
    'PropertyDetails'=>'Property Details',
    'Bedrooms'=>'Bedrooms',
    'AllRooms'=>'All Rooms',
    'Area'=>'Area',
    'Livingroom'=>'Livingroom',
    'YearBuilt'=>'Year Built',
    'Kitchen'=>'Kitchen',
    'Type'=>'Type',
    'EstateLocation'=>'Estate Location',
    'FloorPlans'=>'Floor Plans',
    //footer
    'all'=>'All Rights Reserved',
    'news'=>'The News',
    'newss'=>'Contact',
    'lorem'=>' Share your opinion',
    'masseg'=>'Message',
    'send'=>'Send',
    'subscription'=>'Subscription',
    'email'=>'E-mail',
    'company'=>'Company',
    'litar'=>'Lorem Ipsum is a virtual model that is placed in designs to be presented to the client to visualize the way texts are placed in designs, whether they are printed designs',









    //about



];
