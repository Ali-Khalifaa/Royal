<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    //navbar
    'home' =>'الرئيسيه',
    'about_Us'=>'معلومات عنا',
    'events' => 'الأحداث',
    'projects' => 'المشاريع',
    'commercial' => 'تجاري',
    'residential' => 'سكني',
    'educational' => 'ساحلي',
    'resort' => 'السخنه',
    'media_Center' => 'المركز الاعلامي',
    'careers' => 'وظائف',
    'contact' => 'تواصل معنا',
    'language' => 'اللغة',
    'title' => ' أبدأطريقك الأن',
    'your' => 'رحلتك مع',
    'board_of_directors'=>' كلمة مجلس الادارة',
    'clientsay'=>'أراء العملاء',
    'le'=>'جنية',
    'metr'=>'متر',
    'bedroom'=>'غرفة نوم',
    'bathroom'=>'حمام',
    'exclusives'=>'حصريتنا',
    'properties'=>'خصائص مميزة',
    'commercial_pro' => ' مشاريع تجارية',
    'commercial_re' => ' مشاريع سكنية',
    'Quicklink'=>'رابط سريع',
    'address'=>'43 مكرم عبيد الرئيسي - مدينة نصر - الدور السابع - شقة 71',
    'Comments'=>'أترك تعليقا',
    'commercialprojects'=>'مشاريع سكنية ',
    'educationalprojects'=>'المشاريع الساحليه ',
    'Jobdetails'=>'تفاصيل الوظيفة',
    'Workresponsibilities'=>'مسؤوليات العمل',
    'Abouttheposition'=>'حول المنصب ',
    'Workrequirements'=>'متطلبات العمل',
    'Feeton'=>'قدم علي',
    'subject'=>'موضوع',
    'name'=>'اسم',
    'email'=>'بريد إلكتروني',
    'phone'=>'هاتف',
    'messege'=>'رسالة',
    'ProjectDetails'=>'تفاصيل المشروع',
    'Location'=>'الموقع',
    'EnterYourName'=>'أدخل أسمك',
    'Yournamehere'=>'أسمك هنا.....',
    'EnterYourMAil'=>'أدخل البريد الألكترونى',
    'Youremailhere'=>'بريدك الإلكتروني هنا ....',
    'EnterYourMessege'=>'أدخل الرسالة',
    'Enteryourmessegehere'=>'أدخل رسالتك هنا....',


    'PropertyDetails'=>'تفاصيل اوضح',

    'Bedrooms'=>'غرف نوم',
    'AllRooms'=>'عدد الغرف',
    'Area'=>'مساحة',
    'Livingroom'=>'غرفة المعيشة',
    'YearBuilt'=>'بنيت عام',
    'Kitchen'=>'مطبخ',
    'Type'=>'النوع',
    'EstateLocation'=>'موقع العقار',
    'FloorPlans'=>'مخطط المبنى',


    //footer
    'all'=>'كل الحقوق محفوظة',
    'news'=>'موجز الأخبار',
    'newss'=>'للتواصل',
    'lorem'=>'شاركنا برأيك',
    'subscription'=>'الإشتراك',
    'email'=>'بريدك الالكتروني',
    'masseg'=>'الرسالة',
    'send'=>'ارسال',
    'company'=>'الشركة',
    'litar'=>'لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه',





    //about



];
